import json,sys
import boto3
from botocore.exceptions import ClientError

def create_cloudwatch_metric_alarm(AlarmName,MetricName,Namespace,Threshold,ComparisonOperator,AlarmActions):
    try:
        client = boto3.client('cloudwatch')
        response = client.put_metric_alarm(
            AlarmName=AlarmName,
            AlarmDescription=AlarmName,
            MetricName=MetricName,
            Namespace=Namespace,
            Statistic='Average',
            Period=120,
            EvaluationPeriods=2,
            Threshold=Threshold,
            ComparisonOperator=ComparisonOperator,
            AlarmActions=[AlarmActions]
        )          
    except ClientError as e:
        print("Unexpected error: {}".format(e))
        return {'Status': False}
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        return {'Status': True}
    else:
        return {'Status': False}

def create_asg_scaling_policy(AutoScalingGroupName,PolicyName,ThresholdType):
    if ThresholdType == 'high':
        StepAdjustments = {
                        'MetricIntervalLowerBound': 0.0,
                        'ScalingAdjustment': 1
        }   
    elif ThresholdType == 'low':
        StepAdjustments = {
                        'MetricIntervalUpperBound': 0.0,
                        'ScalingAdjustment': 1
        } 
    else:
        print('ERROR : Set ThresholdType to high/low')
        sys.exit(1)
    try:
        client = boto3.client('autoscaling')
        response = client.put_scaling_policy(
                AutoScalingGroupName=AutoScalingGroupName,
                PolicyName=PolicyName,
                PolicyType='StepScaling',
                AdjustmentType='ChangeInCapacity',
                MetricAggregationType='Average',
                StepAdjustments=[StepAdjustments]
        )          
    except ClientError as e:
        print("Unexpected error: {}".format(e))
        return {'Status': False}
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        return {'Status': True,'PolicyARN':response['PolicyARN']}
    else:
        return {'Status': False}

def create_asg_lifecycle_hook(LifecycleHookName,AutoScalingGroupName,LifecycleTransition,RoleARN,NotificationTargetARN,NotificationMetadata):
    subnetList = ','.join(subnetList)
    try:
        client = boto3.client('autoscaling')
        response = client.put_lifecycle_hook(
            LifecycleHookName=LifecycleHookName,
            AutoScalingGroupName=AutoScalingGroupName,
            LifecycleTransition=LifecycleTransition,
            RoleARN=RoleARN,
            NotificationTargetARN='string',
            NotificationMetadata='string',
            HeartbeatTimeout=2000,
            DefaultResult='CONTINUE'
        )          
    except ClientError as e:
        print("Unexpected error: {}".format(e))
        return False
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        return True
    else:
        return False


def create_asg(AutoScalingGroupName,LaunchConfigurationName,subnetList):
    #subnetList = ','.join(subnetList)
    try:
        client = boto3.client('autoscaling')
        response = client.create_auto_scaling_group(
            AutoScalingGroupName=AutoScalingGroupName,
            LaunchConfigurationName=LaunchConfigurationName,
            MaxSize=0,
            MinSize=0,
            VPCZoneIdentifier=subnetList
        )          
    except ClientError as e:
        print("Unexpected error: {}".format(e))
        return {'Status': False}
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        return {'Status': True}
    else:
        return {'Status': False}


def create_e2e_asg(AutoScalingGroupName,LaunchConfigurationName,subnetList):
    #create_asg('asg123','mp-pool-v1','subnet-07f4f4aecf1ce1ab0,subnet-00c6369cc24b05ac1,subnet-0c700dfc4c74dccf6')
    #create_asg_scaling_policy('asg123','cpu-high-mp','high')
    #create_asg_scaling_policy('asg123','memory-high-mp','high')
    #create_asg_scaling_policy('asg123','cpu-low-mp','low')
    #create_asg_scaling_policy('asg123','memory-low-mp','low')
    #create_cloudwatch_metric_alarm('CPU High','CPUUtilization','AWS/EC2',80,'GreaterThanOrEqualToThreshold','arn:aws:autoscaling:us-east-1:388376138984:scalingPolicy:e7d84e97-cb8b-41f5-95dd-b53f56c09e83:autoScalingGroupName/asg123:policyName/cpu-high-mp')
    #create_cloudwatch_metric_alarm('Memory High','mem_used_percent','CWAgent',80,'GreaterThanOrEqualToThreshold','arn:aws:autoscaling:us-east-1:388376138984:scalingPolicy:e7d84e97-cb8b-41f5-95dd-b53f56c09e83:autoScalingGroupName/asg123:policyName/cpu-high-mp')
    #create_cloudwatch_metric_alarm('CPU Low','CPUUtilization','AWS/EC2',10,'GreaterThanOrEqualToThreshold','arn:aws:autoscaling:us-east-1:388376138984:scalingPolicy:e7d84e97-cb8b-41f5-95dd-b53f56c09e83:autoScalingGroupName/asg123:policyName/cpu-high-mp')
    #create_cloudwatch_metric_alarm('Memory Low','mem_used_percent','CWAgent',10,'GreaterThanOrEqualToThreshold','arn:aws:autoscaling:us-east-1:388376138984:scalingPolicy:e7d84e97-cb8b-41f5-95dd-b53f56c09e83:autoScalingGroupName/asg123:policyName/cpu-high-mp')
    #create_asg_lifecycle_hook(LifecycleHookName,AutoScalingGroupName,'autoscaling:EC2_INSTANCE_LAUNCHING',RoleARN,NotificationTargetARN,NotificationMetadata)
    #create_asg_lifecycle_hook(LifecycleHookName,AutoScalingGroupName,'autoscaling:EC2_INSTANCE_TERMINATING',RoleARN,NotificationTargetARN,NotificationMetadata)
    pass