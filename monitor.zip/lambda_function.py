import json,sys
import boto3
from botocore.exceptions import ClientError
import logging
from  time import time
import asg_helpers

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    Project = os.getenv("Project")
    SubType = os.getenv("SubType")
    query = [{'Project':Project,'SubType':SubType}]
    asg_status = get_asgs_by_tag(query)
    if asg_status['Status']:
        asg_list = asg_status['asg_list']
        for each_asg in asg_list:
            print(each_asg)
    else:
        return {
                'statusCode': 404,
                'body': 'No ASGS matching tags : {}'.format(query)
            }